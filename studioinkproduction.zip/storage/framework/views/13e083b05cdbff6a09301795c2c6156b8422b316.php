<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="<?php echo e(asset('sass/photograph.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'Edit Photograph'); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="tittle">edit photography</div>
        <div class="header">
            <div class="selector active" onclick="tooglebtn2(0)">
                <h3 class="opsi active">Concept</h3>
                <span class="line active"></span>
            </div>
            <div class="selector" onclick="tooglebtn2(1)">
                <h3 class="opsi">Document</h3>
                <span class="line"></span>
            </div> 
        </div>
        <div class="containerGallery" id="containerGal">
            <div class="gallery">
                <div class="gambar" style="background-color: black;" onclick="location.href='<?php echo e(url('/dashbord/tambahConcept?table=concept')); ?>'">
                    <div class="komentar" style="color:white;">Tambah Data</div>
                </div>
                <?php $__currentLoopData = $ConceptPhotography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/ConceptPhotography/<?php echo e($item -> fileName); ?>);">
                    <div class="komentar">
                        <span><?php echo e($item -> imageComment); ?></span><br>
                        <form action="" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="table" value="concept">
                            <button type="submit" name="id" value="<?php echo e($item ->id); ?>">Hapus</button>
                        </form>
                    </div>
                </div>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="gallery">
                <div class="gambar" style="background-color: black;" onclick="location.href='<?php echo e(url('/dashbord/tambahDocument?table=document')); ?>'">
                    <div class="komentar" style="color:white;">Tambah Data</div>
                </div>
                <?php $__currentLoopData = $DocumentPhotography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/DocumentPhotography/<?php echo e($item -> fileName); ?>);">
                    <div class="komentar">
                        <span><?php echo e($item -> imageComment); ?></span><br>
                        <form action="" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="table" value="document">
                            <button type="submit" name="id" value="<?php echo e($item -> id); ?>">Hapus</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/auth/photographyControl.blade.php ENDPATH**/ ?>