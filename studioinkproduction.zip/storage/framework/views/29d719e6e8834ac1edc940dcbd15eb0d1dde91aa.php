<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- css -->
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('sass/layout.css')); ?>">
    <!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <link rel="icon" href="<?php echo e(url('/')); ?>/storage/img/studioink.png">
    <title><?php echo $__env->yieldContent('tittle'); ?></title>
</head>
<body>
    <!-- navbar section -->
        <div class="navbar" id="navbar">
        <div class="logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/')); ?>/storage/img/studioink.png" alt=""></a></div>
            <div class="mobile-menu-button" id="mobile-menu-button" onclick="tooglebtn1()">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="selection">
                <ul>
                    <li onmouseover="lineover(0)" onmouseout="lineout(0)"><a href="<?php echo e(url('/')); ?>" class="nav-select">Home</a><span class="nav-line"></span></li>
                    <li onmouseover="lineover(1)" onmouseout="lineout(1)"><a href="<?php echo e(url('/#client')); ?>" class="nav-select">Clients</a><span class="nav-line"></span></li>
                    <li onmouseover="lineover(2)" onmouseout="lineout(2)"><a href="<?php echo e(url('/#portfolio')); ?>" class="nav-select">Portfolio</a><span class="nav-line"></span></li>
                </ul>
            </div>
        </div>
        <div class="big-nav" id="select">
            <div class="selection" onclick="tooglebtn1()" >
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/#client')); ?>">Clients</a>
                <a href="<?php echo e(url('/#portfolio')); ?>">Portfolio</a> 
            </div>
        </div>
    <!-- end of navbar section -->

    <?php echo $__env->yieldContent('content'); ?>
    
    <div class="footer" id="contact">
        <div class="email"><span>Contact Us! -- <a href="mailto:info@studioinkproduction.com">info@studioinkproduction.com</a></span></div>
        <div class="socmed">
            <a href="#"><img src="<?php echo e(url('/')); ?>/storage/img/youtube.png" alt=""></a>
            <a href="#"><img src="<?php echo e(url('/')); ?>/storage/img/whatsap.png" alt=""></a>
            <a href="#"><img src="<?php echo e(url('/')); ?>/storage/img/instagram.png" alt=""></a>
        </div>
    </div>
    <div class="scroll-up" onclick="location.href='#navbar'">
        <span></span>
        <span></span>
        <span></span>
    </div>
</body>
<!-- scroll animate -->
<script src="https://unpkg.com/scroll-out/dist/scroll-out.min.js"></script>
<script>
    ScrollOut();
</script>
<!-- scroll up -->
<?php echo $__env->yieldContent('js'); ?>
</html><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/template/layout.blade.php ENDPATH**/ ?>