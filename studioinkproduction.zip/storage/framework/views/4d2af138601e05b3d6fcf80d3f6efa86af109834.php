<?php $__env->startSection('css'); ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="<?php echo e(asset('sass/login.css')); ?>" rel="stylesheet" type="text/css" >
<style>
    .footer{
        width: 100% !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'AdminLogin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="login">
        <span>Login Admin</span>
        <div class="card">
            <form method="post" class="card-body" action="/postlogin">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="Email">Email</label>
                    <input type="email" class="form-control" id="Email" aria-describedby="emailHelp" placeholder="youremail@example.com" name="email">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" placeholder="Your Password" name="password">
                </div>
                <?php if(session('status')): ?>
                    <div class="invalid-text">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-info" name="submit">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/auth/login.blade.php ENDPATH**/ ?>