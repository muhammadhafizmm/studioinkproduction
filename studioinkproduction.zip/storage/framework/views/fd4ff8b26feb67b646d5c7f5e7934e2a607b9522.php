<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('sass/portfolio.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'Videography'); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="tittle">editvideography</div>
        <div class="header">
            <div class="selector active">
                <h3 class="opsi active">All</h3>
                <span class="line active"></span>
            </div>
        </div>
        <div class="containerGallery" id="containerGal">
            <div class="gallery">
                <div class="gambar" style="background-color: #0f4c81;" onclick="location.href='<?php echo e(url('/dashboard/tambahVideo')); ?>'">
                    <div class="tambah"><span>Tambah Data</span></div>
                </div>
                <?php $__currentLoopData = $videography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/thumbnail/<?php echo e($item -> thumbnail); ?>);">
                    <div class="komentar">
                        <div class="komentar"><span><?php echo e($item -> komentar); ?></span></div>
                        <div class="form">
                            <form action="" method="post">
                                <?php echo method_field('delete'); ?>
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="table" value="document">
                                <button type="submit" name="id" class="btn btn-danger" value="<?php echo e($item -> id); ?>">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/pop-up.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/videography/videographyControl.blade.php ENDPATH**/ ?>