<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('sass/portfolio.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'Videography'); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="tittle">editclient</div>
        <div class="header">
            <div class="selector active" onclick="tooglebtn2(0)">
                <h3 class="opsi active">Client Atas</h3>
                <span class="line active"></span>
            </div>
            <div class="selector" onclick="tooglebtn2(1)">
                <h3 class="opsi">Client Bawah</h3>
                <span class="line"></span>
            </div>
        </div>
        <div class="containerGallery" id="containerGal">
            <div class="gallery">
                <div class="gambar" style="background-color: #0f4c81;" onclick="location.href='<?php echo e(url('/dashboard/tambahClient')); ?>'">
                    <div class="tambah"><span>Tambah Data</span></div>
                </div>
                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item -> tipe == 'atas'): ?>
                    <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/client/<?php echo e($item -> nama); ?>);">
                        <div class="komentar">
                            <div class="form">
                                <form action="" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" name="id" value="<?php echo e($item -> id); ?>" class="btn btn-danger">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="gallery">
                <div class="gambar" style="background-color: #0f4c81;" onclick="location.href='<?php echo e(url('/dashboard/tambahClient')); ?>'">
                    <div class="tambah"><span>Tambah Data</span></div>
                </div>
                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item -> tipe == 'bawah'): ?>
                    <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/client/<?php echo e($item -> nama); ?>);">
                        <div class="komentar">
                            <div class="form">
                                <form action="" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" name="id" value="<?php echo e($item -> id); ?>" class="btn btn-danger">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template/dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/client/clientControl.blade.php ENDPATH**/ ?>