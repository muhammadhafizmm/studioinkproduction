<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('sass/portfolio.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'Videography'); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="tittle">videography</div>
        <div class="header">
            <div class="selector active">
                <h3 class="opsi active">All</h3>
                <span class="line active"></span>
            </div>
        </div>
        <?php $j = 0 ?>
        <div class="containerGallery" id="containerGal">
            <div class="gallery">
                <?php $__currentLoopData = $videography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gambar" style="background-image: url(<?php echo e(url('/')); ?>/storage/img/thumbnail/<?php echo e($item -> thumbnail); ?>);" onclick="popingUp(<?php echo e($j); ?>)">
                    <div class="komentar"><span><?php echo e($item -> komentar); ?></span></div>
                </div>
                <?php $j++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="popUp">
            <div class="exit" onclick="popingGone();" onmouseover="pause()">
                <span></span>
                <span></span>
            </div>
            <?php $__currentLoopData = $videography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="object">
                <iframe width="560" height="315" src="<?php echo e($item -> embedlink); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/pop-up.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/videography/index.blade.php ENDPATH**/ ?>