<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('sass/style.css')); ?>" rel="stylesheet" type="text/css" >
<script type="text/javascript"src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'HomePage'); ?>


<?php $__env->startSection('content'); ?>
    <!-- content section -->
    <!-- greeting -->
    <div class="greeting child">
        <h1 data-scroll>STUDIOINKPRODUCTION</h1>
        <span>Photography / Videography</span>
        </div>
        <!-- end of greeting -->
    
        <!-- client -->
        <div class="client child" id="client" data-scroll>
        <div class="all-client">
            <div class="header"><h2>Clients</h2></div>
            <div class="gallery-client" id="gallery1" data-scroll>
                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item -> tipe == 'atas'): ?>
                    <div class="logo-client"><img src="<?php echo e(url('/')); ?>/storage/img/client/<?php echo e($item -> nama); ?>" alt=""></div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="gallery-client" id="gallery2" data-scroll>
                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item -> tipe == 'bawah'): ?>
                    <div class="logo-client"><img src="<?php echo e(url('/')); ?>/storage/img/client/<?php echo e($item -> nama); ?>" alt=""></div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>
        <!-- End of Client -->
    
        <!-- Portfolio -->
        <div class="portfolio child" id="portfolio">
        <div class="header">
            <h2 data-scroll>Portfolio</h2>
        </div>
        <div class="port-content" data-scroll>
            <div class="photograph" onmouseout="portoOut()" onmouseover="portoHover(0)"  onclick="location.href='<?php echo e(url('/photography')); ?>';">
                <div class="overlay"></div>
                <h3>Photography</h3>
                <span>View</span>
            </div>
            <div class="videograph" onmouseout="portoOut()" onmouseover="portoHover(1)" data-scroll onclick="location.href='<?php echo e(url('/videography')); ?>'">
                <div class="overlay"></div>
                <h3>Videography</h3>
                <span>View</span>
            </div>
        </div>
        </div>
    <!-- end of content section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/home.blade.php ENDPATH**/ ?>