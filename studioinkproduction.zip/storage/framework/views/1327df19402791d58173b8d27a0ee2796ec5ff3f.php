<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('sass/photograph.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle', 'Photograph'); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="tittle">photography</div>
        <div class="header">
            <div class="selector active" onclick="tooglebtn2(0)">
                <h3 class="opsi active">Concept</h3>
                <span class="line active"></span>
            </div>
            <div class="selector" onclick="tooglebtn2(1)">
                <h3 class="opsi">Document</h3>
                <span class="line"></span>
            </div> 
        </div>
        <div class="containerGallery" id="containerGal">
            <div class="gallery">
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
            </div>
            <div class="gallery">
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/2.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/9.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
                <div class="gambar" style="background-image: url(img/3.jpg);">
                    <div class="komentar"><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</span></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muhammadhafizm\Documents\Web\studioinkproduction\apps\studioinkproduction\resources\views/photograph.blade.php ENDPATH**/ ?>