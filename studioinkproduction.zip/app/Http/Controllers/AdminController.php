<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        return view('auth.dashbord');
    }
    public function editPhotography()
    {
        $ConceptPhotography = \App\conceptphoto::all();
        $DocumentPhotography = \App\documentphoto::all();
        return view('photography.photographyControl', ['ConceptPhotography' => $ConceptPhotography], ['DocumentPhotography' => $DocumentPhotography]);
    }
    public function editVideography()
    {   
        $videography = \App\videograp::all();
        return view('videography.videographyControl', ['videography'=> $videography]);
    }
    public function editClient()
    {
        $client = \App\client::all();
        return view('client.clientControl', ['client' => $client]);
    }
}
