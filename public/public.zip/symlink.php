<?php 
symlink('/home/studioi1/laravel/storage/app/public', 'home/studioi1/public_html/storage')
?>